export class Product {
    id: number;
    name: string;
    description: string;
    isAvailable: boolean;
    price: number;
}
