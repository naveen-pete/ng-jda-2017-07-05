import { StoreAppMcPage } from './app.po';

describe('store-app-mc App', () => {
  let page: StoreAppMcPage;

  beforeEach(() => {
    page = new StoreAppMcPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
