import { Component } from '@angular/core';
import { Product } from "app/products/product";

@Component({
    selector: 'app-products',
    templateUrl: './products.component.html',
    styles: [
        `
        h2 {
            color: red;
        }
        `
    ]
})
export class ProductsComponent {
    product: Product;
    productList: Product[];
    showAlert = false;

    constructor() {
        this.product = new Product();
        this.productList = [];
    }

    onAddProduct() {
        let newProduct = new Product();
        newProduct.name = this.product.name;
        newProduct.description = this.product.description;
        newProduct.isAvailable = this.product.isAvailable;
        newProduct.price = this.product.price;
        
        this.productList.push(newProduct);
        this.product = new Product();

        console.log('New product added successfully!');
        console.log(this.productList);
        this.showAlert = true;

        setTimeout(() => {
            this.showAlert = false;
        }, 3000);
    }
}
