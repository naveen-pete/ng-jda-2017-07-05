import { Component, OnInit } from '@angular/core';

import { Customer } from '../../models/customer';
import { CustomersService } from '../../services/customers.service';
import { LoggingService } from '../../services/logging.service';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent implements OnInit {
  customer: Customer;

  constructor(
    private customersService: CustomersService,
    private loggingService: LoggingService
  ) { }

  ngOnInit() {
    this.customer = this.customersService.getCustomer(4);
  }

  onSave() {
    this.loggingService.logMessage('Customer Form - Save button clicked.');
  }
}
