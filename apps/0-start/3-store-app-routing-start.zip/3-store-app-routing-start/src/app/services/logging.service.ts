export class LoggingService {
    logMessage(message: string) {
        console.log('[LoggingService.logMessage()]', message);
    }
}
