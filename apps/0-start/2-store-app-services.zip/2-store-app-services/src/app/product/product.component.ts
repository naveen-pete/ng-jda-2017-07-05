import { Component, EventEmitter, Input, Output } from '@angular/core';

import { Product } from '../models/product';
import { StatusEventData } from '../models/status-event-data';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  @Input() product: Product;
  @Input() id: number;
  @Output() statusChanged = new EventEmitter<StatusEventData>();


  onSetTo(status: string) {
    let statusEventData = new StatusEventData();
    statusEventData.id = this.id;
    statusEventData.newStatus = status;

    this.statusChanged.emit(statusEventData);
    
    console.log('Product status changed, new status: ' + status);
  }
}
