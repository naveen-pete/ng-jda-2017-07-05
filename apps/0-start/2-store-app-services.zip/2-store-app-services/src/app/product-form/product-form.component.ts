import { Component, EventEmitter, Output } from '@angular/core';

import { Product } from '../models/product';

@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent {
  @Output() productAdded = new EventEmitter<Product>();

  onCreateProduct(productName: string, productStatus: string) {
    let product = new Product();
    product.name = productName;
    product.status = productStatus;
    
    this.productAdded.emit(product);

    console.log('Product status changed, new status: ' + productStatus);
  }
}
