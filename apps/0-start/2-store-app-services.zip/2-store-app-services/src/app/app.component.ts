import { Component } from '@angular/core';

import { Product } from './models/product';
import { StatusEventData } from './models/status-event-data';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  products: Product[] = [
    {
      name: 'Product 1',
      status: 'created'
    },
    {
      name: 'Product 2',
      status: 'ordered'
    }
  ];

  onProductAdded(newProduct: Product) {
    this.products.push(newProduct);
  }

  onStatusChanged(updateInfo: StatusEventData) {
    this.products[updateInfo.id].status = updateInfo.newStatus;
  }
}
