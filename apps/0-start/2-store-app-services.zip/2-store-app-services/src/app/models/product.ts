export class Product {
    name: string;
    status: string;
}