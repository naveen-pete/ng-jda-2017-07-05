export class StatusEventData {
    id: number; 
    newStatus: string;
}